create trigger TR_EM
  before insert or update or delete
  on T_EMPLOYEE
  begin 
  if (to_char(sysdate,'DAY') in('星期六','星期日'))
    or (to_char(sysdate,'HH24:MI')NOT BETWEEN '09:00'AND '18:00')THEN 
    RAISE_APPLICATION_ERROR(-00001,'不允许非工作时间修改');
  end if;
  end ;
/

