create view VIEW_TEMP as
  select  avg(SAL) ,sum(sal) from T_EMPLOYEE
/

