create trigger AUTOINCREMENT
  before insert
  on T_EMPLOYEE
  for each row
  when (NEW.EMPNO IS NULL)
  begin
    select SEQ_EM.NEXTVAL INTO :NEW.EMPNO FROM DUAL;
  end;
/

